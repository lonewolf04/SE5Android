package com.example.shobhana.feature3;

/**
 * Created by shobhana on 06/04/16.
 */
public class TokenStatus {


        public static final String SENT_TOKEN_TO_SERVER = "sentTokenToServer";
        public static final String REGISTRATION_COMPLETE = "registrationComplete";


}
